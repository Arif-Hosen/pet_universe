<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <title> Revenue Statistics</title>

  <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/frontend/img/logo/favicon.png')); ?>">


  <link href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('assets/admin/css/icons.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('assets/admin/css/style.css')); ?>" rel="stylesheet" type="text/css">

  <style>
    .login-page-container {
      max-width: 440px;
    }
  </style>

  <?php echo $__env->yieldContent('stylesheet'); ?>

</head>
<body class="fixed-left login-body">
<!-- Loader -->
<div id="preloader">
  <div id="status">
    <div class="spinner"></div>
  </div>
</div>
<!-- Begin page -->

<?php if(empty($images[0])): ?>
  <div class="login-page-container mt-5 mx-auto">
    <?php else: ?>
      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">

          <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($item == 0 ? 'active' : ''); ?>">
              <img height="680px" class="d-block w-100 " src="<?php echo e(asset($val->image)); ?>" alt="First slide">
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
      <div class="wrapper-page my-auto">
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
      </div>


      <script src="<?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/admin/js/bootstrap.bundle.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/admin/js/modernizr.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/admin/js/jquery.slimscroll.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/admin/js/waves.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/admin/js/jquery.scrollTo.min.js')); ?>"></script>


      <!-- App js -->
      <script src="<?php echo e(asset('assets/admin/js/app.js')); ?>"></script>
  <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\All Projects\2023\pet_universe\resources\views/layouts/auth.blade.php ENDPATH**/ ?>