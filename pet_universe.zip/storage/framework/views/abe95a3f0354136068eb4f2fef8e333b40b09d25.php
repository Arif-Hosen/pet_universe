
<?php $__env->startSection('content'); ?>
  <div class="card ">
    <div class="card-body">
      <div class="row">
        <div class="col-12 text-center"><a href="<?php echo e(route('home')); ?>" class="logo logo-admin">
            <img src="<?php echo e(asset('assets/text-logo.png')); ?>" height="80" alt="logo">
          </a></div>
      </div>
      <div class="pl-3 pr-3 pb-3">
        <div class="row">
          <div class="col-12 text-center">
            <h3 class="m-2">Login</h3>
          </div>
        </div>
        <?php if(session()->has('status')): ?>
          <?php echo session()->get('status'); ?>

        <?php endif; ?>
        <form class="form-horizontal" action="<?php echo e(route('login')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label class="form-label" for="email">Email</label>
            <div class="d-flex">
              <input type="email" name="email" id="email" placeholder="Enter Your email"
                     class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required>
              <span class="mt-1 "><i class="fa fa-duotone fa-envelope icon login-icon"></i></span>
            </div>

            <span class="spin"></span>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($errors->first('email')); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="form-group">
            <label class="form-label" for="password">Password</label>
            <div class="d-flex">
              <input type="password" name="password" id="password" placeholder="Enter Your Password" autocomplete="off"
                     class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('password')); ?>" required>
              <span class="mt-1 "><i class="fa fa-regular fa-key icon login-icon"></i></span>
            </div>

            <span class="spin"></span>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($errors->first('password')); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="form-group row m-t-20">
            <div class="col-sm-12 text-right">
           <a href="<?php echo e(route('register')); ?>" class="btn btn-primary mr-1 w-md waves-effect waves-light">Register</a>
              <button class="btn btn-success w-md waves-effect waves-light" type="submit">Log In</button>

            </div>
           <a href="<?php echo e(route('password.request')); ?>" class=" mt-3 mx-auto">Forget Password?</a>
          </div>
        </form>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\2023\pet_universe\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>