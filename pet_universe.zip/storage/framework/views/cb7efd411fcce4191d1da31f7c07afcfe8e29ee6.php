

<?php $__env->startSection('stylesheet'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('assets/admin/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <link href="<?php echo e(asset('assets/admin/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet"
        type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <section class="panel">
                        <header class="panel-heading">
                            <h2 class="panel-title">List of Order</h2>
                        </header>
                        <div class="panel-body">
                            <?php if(session()->has('status')): ?>
                                <?php echo session()->get('status'); ?>

                            <?php endif; ?>

                            
                            
                            <div class="table-rep-plugin">
                                <div class="table-responsive mb-0" data-bs-pattern="priority-columns">
                                    <table id="datatable-buttons" class="table table-striped table-bordered" cellspacing="0"
                                        width="100%" style="font-size: 14px">

                                        <thead>
                                            <tr>
                                                <th width="10">#</th>
                                                <th>Payment Info</th>
                                                <th>Customer Info</th>
                                                <th width="200">Animal Info</th>
                                                <th width="50">Amount</th>
                                                <th class="hidden-phone" width="40">Payment Time</th>
                                                <th width="100">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="<?php if($key % 2 == 0): ?> gradeX <?php else: ?> gradeC <?php endif; ?>">
                                                    <td class="p-1"><?php echo e($key + 1); ?></td>
                                                    <td class="p-1">
                                                        <div>
                                                            <p class="font-weight-bold">Payment ID: <span
                                                                    class="text-primary"><?php echo e($val->payment_id); ?></span></p>
                                                            <p class="font-weight-bold">Card NO: <span
                                                                    class="text-primary"><?php echo e($val->card_number); ?></span></p>
                                                        </div>
                                                    </td>
                                                    <td class="p-1">
                                                        <div>
                                                            <p class="font-weight-bold">Name: <span
                                                                    class=""><?php echo e($val->name); ?></span>
                                                            </p>
                                                            <p class="font-weight-bold">Email: <span
                                                                    class=""><?php echo e($val->email); ?></span>
                                                            </p>
                                                            <p class="font-weight-bold">Phone: <span
                                                                    class=""><?php echo e($val->phone); ?></span>
                                                            </p>
                                                        </div>
                                                    </td>


                                                    <td class="p-1">
                                                        <?php $__currentLoopData = json_decode($val->animal); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="border-bottom">
                                                                <p class="font-weight-bold">Animal: <span
                                                                        class=""><?php echo e($item->name); ?> ×
                                                                        <?php echo e($item->qty); ?></span></p>

                                                                <p class="font-weight-bold">Sub-Total: <span
                                                                        class=""><?php echo e($item->subtotal); ?></span>
                                                                </p>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </td>
                                                    <td class="p-1"><?php echo e($val->amount); ?></td>
                                                    <td width="200" class="p-1">
                                                        <?php echo e(date('F d, Y h:i A', strtotime($val->created_at))); ?></td>

                                                    <?php
                                                        $statusColor = '';
                                                        if (App\Enums\OrderStatusEnum::ACCEPT == $val->status) {
                                                            $statusColor = 'success';
                                                        } elseif (App\Enums\OrderStatusEnum::PENDING == $val->status) {
                                                            $statusColor = 'warning';
                                                        } elseif (App\Enums\OrderStatusEnum::CANCEL == $val->status) {
                                                            $statusColor = 'danger';
                                                        } else {
                                                            $statusColor = 'info';
                                                        }
                                                    ?>
                                                    <?php if(\App\Helper\CustomHelper::canView('Create User|Manage User|Delete User|View User|List Of User', 'Super Admin')): ?>
                                                        <td class="text-capitalize p-1" width="100">
                                                            <select id="order_status_<?php echo e($val->id); ?>" name="status" required
                                                                data-id="<?php echo e($val->id); ?>"
                                                                class="form-control font-weight-bold <?php echo e($statusColor); ?> ">

                                                                <option class="text-success font-weight-bold"
                                                                    value="<?php echo e(App\Enums\OrderStatusEnum::ACCEPT); ?>"
                                                                    <?php if(App\Enums\OrderStatusEnum::ACCEPT == $val->status): ?> selected <?php endif; ?>>
                                                                    <?php echo e(ucfirst(App\Enums\OrderStatusEnum::ACCEPT)); ?>

                                                                </option>
                                                                <option class="text-warning font-weight-bold"
                                                                    value="<?php echo e(App\Enums\OrderStatusEnum::PENDING); ?>"
                                                                    <?php if(App\Enums\OrderStatusEnum::PENDING == $val->status): ?> selected <?php endif; ?>>
                                                                    <?php echo e(ucfirst(App\Enums\OrderStatusEnum::PENDING)); ?>

                                                                </option>
                                                                <option class="text-danger font-weight-bold"
                                                                    value="<?php echo e(App\Enums\OrderStatusEnum::CANCEL); ?>"
                                                                    <?php if(App\Enums\OrderStatusEnum::CANCEL == $val->status): ?> selected <?php endif; ?>>
                                                                    <?php echo e(ucfirst(App\Enums\OrderStatusEnum::CANCEL)); ?>

                                                                </option>
                                                                <option class="text-info font-weight-bold"
                                                                    value="<?php echo e(App\Enums\OrderStatusEnum::DELIVERED); ?>"
                                                                    <?php if(App\Enums\OrderStatusEnum::DELIVERED == $val->status): ?> selected <?php endif; ?>>
                                                                    <?php echo e(ucfirst(App\Enums\OrderStatusEnum::DELIVERED)); ?>

                                                                </option>

                                                            </select>
                                                        </td>
                                                    <?php endif; ?>
                                                    <?php if($role == 'Customer'): ?>
                                                    <td class="text-capitalize p-1" width="100">
                                                       <button class="btn ms-2 btn-<?php echo e($statusColor); ?>"><?php echo e(ucfirst($val->status)); ?></button>
                                                    </td>
                                                <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                            
                            
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="userDeleteModal" tabindex="-1" role="dialog" aria-labelledby="userDeleteModal"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    
                    <h4>Delete animal</h4>
                </div>
                <div class="modal-body">
                    <strong>Are You Sure Delete animal</strong>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">No</button>
                    <button type="button" class="btn btn-success btn-sm yes-btn">Yes</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.colVis.min.js')); ?>"></script>
    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/sweetalert2/sweetalert2.all.min.js')); ?>"></script>



    <script>
        $(document).ready(function() {
            // $('#datatable-buttons').DataTable();

            var table = $('#datatable-buttons').DataTable({
                lengthChange: false,
                buttons: ['copy', 'excel', 'pdf', 'colvis']
            });

            table.buttons().container()
                .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');


            $(document).on('change', 'select[name="status"]', function() {
                var status = $(this).val();
                // console.log(status);
                var id = $(this).data('id')
                $.ajax({
                    url: "<?php echo e(route('ajax.update.order.status')); ?>",
                    method: "post",
                    dataType: "html",
                    data: {
                        'id': id,
                        'status': status
                    },
                    success: function(data) {
                        if (data === "success") {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000
                            });
                        }
                    }
                });
            });






            $(document).on('change', 'input[name="onoffswitchtwo"]', function() {
                var featured = 'no';
                var id = $(this).data('id')
                var isChecked = $(this).is(":checked");
                if (isChecked) {
                    featured = 'yes';
                }
                $.ajax({
                    url: "<?php echo e(route('ajax.update.animal.featured')); ?>",
                    method: "post",
                    dataType: "html",
                    data: {
                        'id': id,
                        'featured': featured
                    },
                    success: function(data) {
                        if (data === "success") {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000
                            });
                        }
                    }
                });
            });



            $(document).on('change', 'input[name="onoffswitchdeal"]', function() {
                var today_deal = 'no';
                console.log(today_deal);
                var id = $(this).data('id')
                console.log("log2", id);
                var isChecked = $(this).is(":checked");
                console.log("log3", id);
                if (isChecked) {
                    today_deal = 'yes';
                }
                $.ajax({
                    url: "<?php echo e(route('ajax.update.animal.today_deal')); ?>",
                    method: "post",
                    dataType: "html",
                    data: {
                        'id': id,
                        'today_deal': today_deal
                    },
                    success: function(data) {
                        if (data === "success") {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000
                            });

                        }
                    }
                });
            });







            $(document).on('click', '.yes-btn', function() {
                var pid = $(this).data('id');
                var $this = $('.delete_' + pid)
                $.ajax({
                    url: "<?php echo e(route('animal.destroy')); ?>",
                    method: "delete",
                    dataType: "html",
                    data: {
                        id: pid
                    },
                    success: function(data) {
                        if (data === "success") {
                            $('#userDeleteModal').modal('hide')
                            $this.closest('tr').css('background-color', 'red').fadeOut();
                        }
                    }
                });
            })

            $(document).on('click', '.btn-delete', function() {
                var pid = $(this).data('id');
                $('.yes-btn').data('id', pid);
                $('#userDeleteModal').modal('show')
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\2023\pet_universe\resources\views/admin/order/index.blade.php ENDPATH**/ ?>