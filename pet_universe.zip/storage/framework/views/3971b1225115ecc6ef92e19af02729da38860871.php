
<?php $__env->startSection('stylesheet'); ?>
<link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap4.min.css" rel="stylesheet">
  <style>
      .panel{
          padding: 0px 0px !important;
      }
      .panel-heading{
          padding: 10px 0px;
          background-color: rgb(16,38,74);
          color: white;
          border-radius: 5px;
      }
      .btn-job-list{
          background-color: rgb(16,38,74);
          color: white;
      }
      .btn-job-list:hover{
          background-color: #0D6EFD;
          color: white;
      }
      .center {
          display: block;
          margin-left: auto;
          margin-right: auto;
          width: 50%;
      }
      img {
          max-width: 100%;
          height: auto;
      }

      .product-list-img {
          width: 100px;
          min-height: 100px;
          max-height: auto;
          float: left;
          margin: 3px;
          padding: 3px;
      }
  </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!-- Breadcrumb Area Start -->
<div class="section breadcrumb-area bg-bright">
    <div class="container">
        <div class="row">
            <div class="text-center col-12">
                <div class="breadcrumb-wrapper">
                    
                    <h2 class="breadcrumb-title">All Products</h2>
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li>products</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Area End -->

<!-- Shop Section Start -->
<div class="section section-margin">
    <div class="container">
        <div class="row">
            <div class="col-12">

                <!--shop toolbar start-->
                <div class="p-2 mb-8 border shop_toolbar_wrapper flex-column flex-md-row">

                    <!-- Shop Top Bar Left start -->
                    <div class="shop-top-bar-left">

                        <div class="shop_toolbar_btn">
                            <button data-role="grid_4" type="button" class="active btn-grid-4" title="Grid"><i class="ti-layout-grid4-alt"></i></button>
                            <button data-role="grid_list" type="button" class="btn-list" title="List"><i class="ti-align-justify"></i></button>
                        </div>
                        <div class="shop-top-show">
                            <span>Showing 1–12 of 39 results</span>
                        </div>

                    </div>
                    <!-- Shop Top Bar Left end -->

                    <!-- Shopt Top Bar Right Start -->
                    <div class="shop-top-bar-right">

                        <h4 class="title me-2">Short By: </h4>
                        <!-- Header Action Search Button Start -->
                           
                            <!-- Search Form and Button Start -->
                            <form class="header-search-form" action="#">
                                <input type="text" class="header-search-input" placeholder="Search Our Store">
                                <button class="header-search-button"><i class="icon-magnifier icons"></i></button>
                            </form>
                            <!-- Search Form and Button End -->

                        <!-- Header Action Search Button End -->

                        
                    </div>
                    <!-- Shopt Top Bar Right End -->

                </div>
                <!--shop toolbar end-->

                <!-- Shop Wrapper Start -->
                <div class="row shop_wrapper grid_4">

                    

<?php $__currentLoopData = $animal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    

                    <!-- Single Product Start -->
                    <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 product">
                        <div class="product-inner">
                            <div class="thumb">
                                <a href="single-product.html" class="image">
                                    <img class="fit-image" style="height: 270px; width: 270px;" src="<?php echo e(asset($val->image)); ?>" alt="Product" />
                                </a>
                                <div class="action-wrapper">
                                    <a id="<?php echo e($val->id); ?>" class="action quickview" data-bs-toggle="modal" data-bs-target="#quick-view"><i class="ti-plus"></i></a>
                                    
                                    <a class="add-to-cart-btn action cart" data-animal-id="<?php echo e($val->id); ?> title="Cart"><i class="ti-shopping-cart"></i></a>
                                </div>
                            </div>
                            <div class="content">
                                <h5 class="title"><a href="<?php echo e(route('animal_details', $val->name)); ?>"><?php echo e($val->name); ?></a></h5>
                                
                                <span class="price">
                                    <?php if($val->discount_price == null): ?>
                                    <span class="new">$<?php echo e($val->selling_price); ?></span>
                                    <?php else: ?>
                                    <span class="new">$<?php echo e($val->discount_price); ?></span>
                                    <span class="old">$<?php echo e($val->selling_price); ?></span>
                                    <?php endif; ?>
                                </span>
                                <p><?php echo e($val->description); ?></p>
                                <!-- Cart Button Start -->
                                <div class="cart-btn action-btn">
                                    <div class="action-cart-btn-wrapper d-flex">
                                        <div class="add-to_cart">
                                            <a class="add-to-cart-btn btn btn-primary btn-hover-dark rounded-0" data-animal-id="<?php echo e($val->id); ?> href="cart.html">Add to cart</a>
                                        </div>
                                        
                                        <a href="#/" id="<?php echo e($val->id); ?>" class="action quickview" data-bs-toggle="modal" data-bs-target="#quick-view" title="Quickview"><i class="ti-plus"></i></a>
                                    </div>
                                </div>
                                <!-- Cart Button End -->
                            </div>
                        </div>
                    </div>
                    <!-- Single Product End -->

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
                <!-- Shop Wrapper End -->

                <!--shop toolbar start-->
                <div class="mt-10 shop_toolbar_wrapper justify-content-center">

                    <!-- Shopt Top Bar Right Start -->
                    <div class="shop-top-bar-right">
                        <nav>
                            <ul class="pagination">
                                <li class="page-item"><a class="page-link active" href="#/">1</a></li>
                                <li class="page-item"><a class="page-link" href="#/">2</a></li>
                                <li class="page-item"><a class="page-link" href="#/">3</a></li>
                                <li class="page-item">
                                    <a class="page-link rounded-0" href="#/" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <!-- Shopt Top Bar Right End -->

                </div>
                <!--shop toolbar end-->

            </div>
        </div>
    </div>
</div>
<!-- Shop Section End -->






<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- Datatable js -->

      <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
      <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap4.min.js"></script>



      <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css"></script>
      <script type="text/javascript">
        $(document).ready(function () {
          $('#datatable').DataTable();
        });
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\2023\pet_universe\resources\views/site/all_animal_products.blade.php ENDPATH**/ ?>